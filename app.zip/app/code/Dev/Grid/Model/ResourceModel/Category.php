<?php

namespace Dev\Grid\Model\ResourceModel;

class Category extends \Magento\Catalog\Model\ResourceModel\Category
{
}
