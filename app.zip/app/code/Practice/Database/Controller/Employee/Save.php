<?php

namespace Practice\Database\Controller\Employee;

use Practice\Database\Model\Employee;
use Practice\Database\Model\ResourceModel\Employee as EmployeeResourceModel;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Save extends Action
{
    /**
     * @var Employee
     */
    private $employee;
    /**
     * @var EmployeeResourceModel
     */
    private $employeeResourceModel;

    /**
     * Add constructor.
     * @param Context $context
     * @param Employee $employee
     * @param EmployeeResourceModel $employeeResourceModel
     */
    public function __construct(
        Context $context,
        Employee $employee,
        EmployeeResourceModel $employeeResourceModel
    ) {
        $this->employee = $employee;
        $this->employeeResourceModel = $employeeResourceModel;
        parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $employee = $this->employee->setData($params);//TODO: Challenge Modify here to support the edit save functionality
        try {
            $this->employeeResourceModel->save($employee);
            $this->messageManager->addSuccessMessage(__("Successfully added the Employee %1", $params['name']));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__("Something went wrong."));
        }
        /* Redirect back to employee display page */
        $redirect = $this->resultRedirectFactory->create();
        $redirect->setPath('database');
        return $redirect;
    }
}