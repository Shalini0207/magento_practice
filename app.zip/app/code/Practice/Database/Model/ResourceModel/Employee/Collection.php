<?php
namespace Practice\Database\Model\ResourceModel\Employee;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Practice\Database\Model\Employee;
use Practice\Database\Model\ResourceModel\Employee as EmployeeResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Employee::class, EmployeeResourceModel::class);
    }
}