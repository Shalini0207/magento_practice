<?php

namespace Practice\Database\Model;

use Magento\Framework\Model\AbstractModel;
// use Practice\Database\Model\ResourceModel\Employee as EmployeeResourceModel;

class Employee extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel\Employee::class);
    }
}