<?php


namespace Jc\SuperHero\Controller\Hero;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\ResponseInterface;

class Edit extends Action
{

    public function execute()
    {
        // TODO: Challenge Implement Edit page in this execute() method.
    }
}
