<?php

namespace Task\TradeForm\Controller\Trade;

use Task\TradeForm\Model\Trade;
use Task\TradeForm\Model\ResourceModel\Trade as TradeResourceModel;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Save extends Action
{
    /**
     * @var Trade
     */
    private $trade;
    /**
     * @var TradeResourceModel
     */
    private $tradeResourceModel;

    /**
     * Add constructor.
     * @param Context $context
     * @param Trade $trade
     * @param TradeResourceModel $tradeResourceModel
     */
    public function __construct(
        Context $context,
        Trade $trade,
        TradeResourceModel $tradeResourceModel
    ) {
        $this->trade = $trade;
        $this->tradeResourceModel = $tradeResourceModel;
        parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->getRequest()->getParams();
        $trade = $this->trade->setData($params);
        try {
            $this->tradeResourceModel->save($trade);
            $this->messageManager->addSuccessMessage(__("Successfully added the Applicant %1", $params['full_name']));
            // $this->messageManager->addSuccessMessage(__("Successfully added the Applicant %1", $params['serial_no']));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__("Something went wrong."));
        } 
        /* Redirect back to hero display page */
        $redirect = $this->resultRedirectFactory->create();
        $redirect->setPath('tradeform');
        return $redirect;
    }
}
