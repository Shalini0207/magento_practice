<?php


namespace Task\TradeForm\Model\ResourceModel\Trade;


use Task\TradeForm\Model\Trade;
use Task\TradeForm\Model\ResourceModel\Trade as TradeResourceModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Trade::class, TradeResourceModel::class);
    }
}
