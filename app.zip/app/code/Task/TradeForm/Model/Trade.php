<?php


namespace Task\TradeForm\Model;


use Magento\Framework\Model\AbstractModel;

class Trade extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel\Trade::class);
    }
}
