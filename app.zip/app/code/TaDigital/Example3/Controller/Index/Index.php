<?php

namespace TaDigital\Example3\Controller\Index;
use Magento\Framework\Controller\ResultFactory;

class Index extends \Magento\Framework\App\Action\Action
{
    public function execute()
    {
        die("hello I am  controller 3");
        return $this->resultFactory->create(ResultFactory::TYPE_PAGE);
    }
}
