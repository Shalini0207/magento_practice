
var config = {
    map: {
        '*': {
           jsmodule: 'TaDigital_Example3/js/hello',
        }
    }
};
